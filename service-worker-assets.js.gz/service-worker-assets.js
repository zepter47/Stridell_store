self.assetsManifest = {
  "version": "K6t8Jxfa",
  "assets": [
    {
      "hash": "sha256-xCaM/WroSvZyzpLfrFG6EoLXSfRyxkl2GojM8/XQUC4=",
      "url": "Stridell_Origins.styles.css"
    },
    {
      "hash": "sha256-MiKe04rtk2Lomw1HFjw4R8blqGHKtJ6Dlssbb66z/AE=",
      "url": "_content/DaffittTech.NetworkStatus/NetworkService.js"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-xiI2A1m1OLBPDlHUdHFMmkYc8bUXz/vxhxg7nPEty/w=",
      "url": "_content/Shiny.DocumentDb.IndexedDb/shiny-indexeddb.js"
    },
    {
      "hash": "sha256-Kg4kDNZxCEF7V75waSoM1W/mGlLybEut5V6so8Oxy28=",
      "url": "_framework/DaffittTech.NetworkStatus.61cphd8qxm.wasm"
    },
    {
      "hash": "sha256-vj209v7TMHscZnUv9D3QaqBlEQeoWmZE4Nw1T4qu+34=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.u0q80mrplt.wasm"
    },
    {
      "hash": "sha256-m1FCF3uP2gKUZPiidn1jz6MgomFWCVx2/ttvbQIt1F0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.h17fhz4ubu.wasm"
    },
    {
      "hash": "sha256-4/fsOCi6cA5EWV/q1HHVADBf1Qpqq+BSzNyq22EWreg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7nmxbvsah3.wasm"
    },
    {
      "hash": "sha256-acIOGI3JqSgWIacNz/pHKBJNKBOpQ1Z8tCX8YDmRIHc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.1u38xveiiz.wasm"
    },
    {
      "hash": "sha256-0KnNt1hX9O+9AysSpXv8aTbodOn+LVNwOTmN3MnUjjM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.08dhhycrby.wasm"
    },
    {
      "hash": "sha256-zAQJRqoyX0ywbPWcrIan9zfPAzJP91ro7Yj/KKenzzc=",
      "url": "_framework/Microsoft.AspNetCore.Components.ksflsbhcuz.wasm"
    },
    {
      "hash": "sha256-hyVhdjUpyHZZbSg8L54mTM1ZMzP8qbsRT1GFPfuKAW4=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.3tj1rw598p.wasm"
    },
    {
      "hash": "sha256-uTWnW+IznZM0LihHqUnws6t9BX4wkuS+HMTWIZae6Xo=",
      "url": "_framework/Microsoft.CSharp.dz4yo8jaui.wasm"
    },
    {
      "hash": "sha256-yo4mXQQl/ydl7MB6Mv1BgbHLGRM8LU9qFvGn4/+0fiM=",
      "url": "_framework/Microsoft.Extensions.Configuration.2ighdhd1um.wasm"
    },
    {
      "hash": "sha256-upBN5/bJpuCbmjE3Ho9YTBJ/WBDkgo59rnWE5M6/flc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.6o6eit7sus.wasm"
    },
    {
      "hash": "sha256-FPs1VityJ6jXLVw3FgdaCH5MAGeiZX8CR18RjrZHnWk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.wnpgblskiw.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-le5rmrBMDRqKfFdTIfPXMMq+YRlD1okvk+xc6dLUYm8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7t9rn8l3bj.wasm"
    },
    {
      "hash": "sha256-bx8QAZqWHJ9eG1I7FM2M4JmF1PmJKWwxlc9gIZQMQqI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.fw2vb9dioh.wasm"
    },
    {
      "hash": "sha256-oIu8yLUtJP4EGU5Om1fDSAzpY3ffMjl9rKZnwII0XTs=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.47qgfhx9eb.wasm"
    },
    {
      "hash": "sha256-npldTut68mqzQngvA3K/GSRCbYWhEVEjs1SJ18ArUuo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.isypqwhob8.wasm"
    },
    {
      "hash": "sha256-XF5pknv6jWAvFVSqcTV9Mts+7tPpcOgSFwDrFFG+8go=",
      "url": "_framework/Microsoft.Extensions.Logging.8x7p6ttll9.wasm"
    },
    {
      "hash": "sha256-saTIGy795CjKkq1RxBW/fNceLbpvBwe0x/fbWECjoYk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.nuspphmwk2.wasm"
    },
    {
      "hash": "sha256-pyWsUcPd3YLorRQE70Uke2ADx3z5FztEUqfU+lnWTo4=",
      "url": "_framework/Microsoft.Extensions.Options.9w9x65j0r5.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-hhE+p8W36Xt5rxWVHZKZwIPWrKuVoVC5qqRxOCvdPtY=",
      "url": "_framework/Microsoft.IO.RecyclableMemoryStream.yxkatvvqoa.wasm"
    },
    {
      "hash": "sha256-7sCN4qXB33/ef65J9QK/+YNUoXCtWBdBT2EF1FgMeiQ=",
      "url": "_framework/Microsoft.IdentityModel.Abstractions.248sngnkb1.wasm"
    },
    {
      "hash": "sha256-s4PcUGVsWd3RawK+erm+TTtlaW7lKCGUikybScse+Fs=",
      "url": "_framework/Microsoft.IdentityModel.JsonWebTokens.do6a07o59u.wasm"
    },
    {
      "hash": "sha256-6ynDAQ1sEe2EfKrc8n7lUjD8dccDe5hetAmGPxpTKqc=",
      "url": "_framework/Microsoft.IdentityModel.Logging.l0c9d5hrv1.wasm"
    },
    {
      "hash": "sha256-007xuDnm4v+hMpJrxaWzOijbGgrD3RuurnF/l4ibZEQ=",
      "url": "_framework/Microsoft.IdentityModel.Tokens.tgxjdpx9cv.wasm"
    },
    {
      "hash": "sha256-LflsX5/lCKu5OnIeW2ybJ8WnCYONPG6qlURpO5T/y5c=",
      "url": "_framework/Microsoft.JSInterop.38vzmiamit.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-CMXcRIg84k7AstbhcD8rbnPKy2wa/gmsBD8gBgZP1c8=",
      "url": "_framework/MimeMapping.gmxjevqz69.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-O5Mc/Cs88mz1O5N1fxLNl+2f3uXD0E7HuSFqq8JNNOE=",
      "url": "_framework/Shiny.DocumentDb.IndexedDb.t2ixzgdm34.wasm"
    },
    {
      "hash": "sha256-8yn5R/xjwdGCgHtFHOaEFjDWZGNcRirQtgP6F1UX95A=",
      "url": "_framework/Shiny.DocumentDb.hn4qw3rmg4.wasm"
    },
    {
      "hash": "sha256-d1VNMpKXFzhlHkxZSmx8b0SaGc/73Xjoq32c9YjO7IU=",
      "url": "_framework/Stridell_Origins.7otdir6upu.wasm"
    },
    {
      "hash": "sha256-jUEh1mM6mkGdyQrEwowAbpQ8R148PZIAUIOXn0mrgIA=",
      "url": "_framework/Supabase.Core.zcuz262cdn.wasm"
    },
    {
      "hash": "sha256-i3baKTpUA4voBHgpG1KCEXhOQom7BsRz3N4FCywsZ6k=",
      "url": "_framework/Supabase.Functions.das9utiwul.wasm"
    },
    {
      "hash": "sha256-fIDLwe2YAl/vphQoUtljCM5aRD5nbL3EXYlszJRLyfw=",
      "url": "_framework/Supabase.Gotrue.kcc8v0x814.wasm"
    },
    {
      "hash": "sha256-XBrmcfBn9P/tWxdOP8BZzt+Er2JFu2K3zhAWYTFDah0=",
      "url": "_framework/Supabase.Postgrest.c2dibacbnw.wasm"
    },
    {
      "hash": "sha256-uVv6E6kYwaHrayuVaV9LCt6rkkyLzb8yruwLcdoZP3o=",
      "url": "_framework/Supabase.Realtime.r7rezo8ln8.wasm"
    },
    {
      "hash": "sha256-y76yu8B80Dx0eKBpLW7a6YC2em2J/O6ww8+m80LzhXE=",
      "url": "_framework/Supabase.Storage.rox9ole9mr.wasm"
    },
    {
      "hash": "sha256-zig+I7dVOmC5X90UX+XkfblaDBDqC28AFjl2khOCN/s=",
      "url": "_framework/Supabase.qyt6qogdl5.wasm"
    },
    {
      "hash": "sha256-IfHwmRSGdJxZMs6UkM0wf2ON5fW8RFxq2bOUOSazhtw=",
      "url": "_framework/System.Collections.Concurrent.9qrboe88q6.wasm"
    },
    {
      "hash": "sha256-ptexJl+oHbKZ+Sr5wz4mJLCOvVU0NEh1F0+Dng1DdSM=",
      "url": "_framework/System.Collections.Immutable.iyogm466cq.wasm"
    },
    {
      "hash": "sha256-XlL7rF5lwK8DmL2j2rqdNuTDpQut6BmRny+dv2KL1Kw=",
      "url": "_framework/System.Collections.NonGeneric.ivvcq3e87z.wasm"
    },
    {
      "hash": "sha256-QBQ1KtUHk76R831MSqN9jmp3Vc+EaK5DFb4zjnI/GDg=",
      "url": "_framework/System.Collections.Specialized.wcvglxl56b.wasm"
    },
    {
      "hash": "sha256-iAxIF8VpE0uWonrumE1CZb3RWJTIsJzc9s4jsbR7NoA=",
      "url": "_framework/System.Collections.gyuz4ubs4o.wasm"
    },
    {
      "hash": "sha256-44JoI0nrEOuIRdl4Mg6uV8k4k8PskXJTK6R7MgO40pA=",
      "url": "_framework/System.ComponentModel.Primitives.1jfej9ge6y.wasm"
    },
    {
      "hash": "sha256-HrlaOHeKvtybj5o7juOqTsjncS0zW3RBMaR21xAxR+o=",
      "url": "_framework/System.ComponentModel.TypeConverter.637s4s032t.wasm"
    },
    {
      "hash": "sha256-CMFU+b1d2LT8JOuvrfe5QITMKX2d44sVccWUM8Kmno0=",
      "url": "_framework/System.ComponentModel.sbhdiphx0d.wasm"
    },
    {
      "hash": "sha256-mP8fLdAYZ+ynUyosmFy6jReWz52yPVMysgV2NnUJal4=",
      "url": "_framework/System.Console.4x0nohiuxi.wasm"
    },
    {
      "hash": "sha256-1s8MI1051U6VuPY2tIXnyMbp9u/VdnGUTBVVsV5tjnk=",
      "url": "_framework/System.Data.Common.2yeay9akh0.wasm"
    },
    {
      "hash": "sha256-xb9a3B4OXthJKbCkMbAQ9zQ4G1PJveBvkQZRwAz53ug=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.x1cn3kv2hq.wasm"
    },
    {
      "hash": "sha256-REUbevgxahx7+Ta3Yyl5nBwMBSeaDdtySNNRBslzdlo=",
      "url": "_framework/System.Diagnostics.TraceSource.0tzwwas62y.wasm"
    },
    {
      "hash": "sha256-cgluZq/TlrC24KM3mSw8pon2pGiVaNyZatlEktwTzpk=",
      "url": "_framework/System.Diagnostics.Tracing.2je09haapi.wasm"
    },
    {
      "hash": "sha256-+P6iv9BqBaSzIMcl/QoNjmkXV39NyvncqPXZ1Ss7398=",
      "url": "_framework/System.Drawing.8wgi7x9zvd.wasm"
    },
    {
      "hash": "sha256-R8FQ8C5HETXzl5QrDjQHcKh2e7gl/ruIbeVUmGZAJTw=",
      "url": "_framework/System.Drawing.Primitives.dr6is8pck6.wasm"
    },
    {
      "hash": "sha256-lVWvaHLZBpTEth9WGU6aa0JqJIxKdZQu3pwOd8wLMw0=",
      "url": "_framework/System.Formats.Asn1.7dpo4of5kz.wasm"
    },
    {
      "hash": "sha256-ZoKVcaGR/93AKc6snjxeOm0WZx0elgFqjQcV/hbTYmU=",
      "url": "_framework/System.IO.Compression.u39u4gjk9o.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-PO+x96C/PkZ0SBbU+a9mIaUKvAK79n200oqZ/t+TxrE=",
      "url": "_framework/System.IdentityModel.Tokens.Jwt.8p36zpd3sm.wasm"
    },
    {
      "hash": "sha256-3eNGnY5luCOsoBbRxXvRYxe2J3wyrbJnA6C2KCmgZdA=",
      "url": "_framework/System.Linq.3wqg4b2ekq.wasm"
    },
    {
      "hash": "sha256-GzdbdDgsI0YNiDJgcVbQrjFTddtkTU90lOnQHAkWnHo=",
      "url": "_framework/System.Linq.Expressions.3eigav1ped.wasm"
    },
    {
      "hash": "sha256-FsTmn+B0SSGdz+jUSxwdaHI2gtRHJXDfy23+23uI0uM=",
      "url": "_framework/System.Memory.uj6nvrnehj.wasm"
    },
    {
      "hash": "sha256-JcFA7uKVAdBKPeGJjNc8ARcfdAX0YpGZuU/nLbRD5pE=",
      "url": "_framework/System.Net.Http.5498tdhp5c.wasm"
    },
    {
      "hash": "sha256-E0Qs/jMKpzwm6FEJ9avWb3OkQ0/MsTrZBGLeZ6EOv0Q=",
      "url": "_framework/System.Net.NetworkInformation.rivaan8ki6.wasm"
    },
    {
      "hash": "sha256-bJhr+QiskcfS02yMlX1lrPorHkw7ngbuxSW9F8N/9ok=",
      "url": "_framework/System.Net.Ping.4siup158ip.wasm"
    },
    {
      "hash": "sha256-4nXMiptvYw8JV2O4FbkBfLh+Jm59qsAhyksVU6y+Vc8=",
      "url": "_framework/System.Net.Primitives.isa1l91qgs.wasm"
    },
    {
      "hash": "sha256-Ly8I8jSm/1KxMNlzQHjvZV8JcMjqzy9X3BgVjqc+2pE=",
      "url": "_framework/System.Net.WebSockets.Client.ttefkp8n20.wasm"
    },
    {
      "hash": "sha256-p7w4CIGqweYTRPZMyjsrViAQtvBJp/Gd8ItTKYg7hoo=",
      "url": "_framework/System.Net.WebSockets.n8vim2344a.wasm"
    },
    {
      "hash": "sha256-j/orGPp1WbDW9TRouvgYdbl3ncK+dWY428tyqKP02e0=",
      "url": "_framework/System.ObjectModel.ln6z1u24vr.wasm"
    },
    {
      "hash": "sha256-VtSOzaEJRuqH8dggAPiRaOaljRgI6eWoyQYPPDx3qXc=",
      "url": "_framework/System.Private.CoreLib.yamnzi5uhy.wasm"
    },
    {
      "hash": "sha256-6V6jNIujZM2ZSg3B4+F6+FwrVqXeN/pfrms8+W6sNrQ=",
      "url": "_framework/System.Private.Uri.jtzrfdvcw4.wasm"
    },
    {
      "hash": "sha256-uxqFezximY/7QqBiz05os7l68GU473yQhP1x4lJ9GjY=",
      "url": "_framework/System.Private.Xml.Linq.9r7wqr5ket.wasm"
    },
    {
      "hash": "sha256-ovY8V8k8nur+NE3HZonRNvEUtv+4jZangwEDrdZPmuI=",
      "url": "_framework/System.Private.Xml.usxt1mg8ns.wasm"
    },
    {
      "hash": "sha256-M1qwOZIHNQ04r3Rz7QHjFuhGjGZnf98uUS1F0+Oe2PI=",
      "url": "_framework/System.Reactive.vly4ehyc64.wasm"
    },
    {
      "hash": "sha256-ZZ8Yl+tzEDXUuAnCPVKMYQ3olBU48bipKbHLrw78TnI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.ffvu6crlqb.wasm"
    },
    {
      "hash": "sha256-MnoV33rJKyM4ob2m+B4jDhQln2wUkc36gzI6zNKR+ps=",
      "url": "_framework/System.Reflection.Emit.Lightweight.u1f06yqgqz.wasm"
    },
    {
      "hash": "sha256-d3K/0sOH7IpBeQB9qj98KMmsPZy9QPcDIJxaT7Gw7LE=",
      "url": "_framework/System.Reflection.Primitives.nsfubnmzhb.wasm"
    },
    {
      "hash": "sha256-lmzf+Ta9C5X4ZaBvVqY97SbELqEN9880Sl3DLiPFjF8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.im4w8bqg0n.wasm"
    },
    {
      "hash": "sha256-3vPK7QyQMcjXNLacG1SERr7K+dvdBACz5ezsmYKDl2A=",
      "url": "_framework/System.Runtime.InteropServices.a64k6d228g.wasm"
    },
    {
      "hash": "sha256-py/tJu+M7BnERIbOkRVceSzeJZgNA+pO3G33Igpb/o0=",
      "url": "_framework/System.Runtime.Numerics.tn4zu0vweg.wasm"
    },
    {
      "hash": "sha256-+YaMGRdd7ZmWXFWXUbs7wAb9AErwWb+DXX3IATt3hHU=",
      "url": "_framework/System.Runtime.Serialization.Formatters.f6ygocimgm.wasm"
    },
    {
      "hash": "sha256-9erivkhskY9zIS6nP9qwGeaNX/x3ROBrd/v4ijGZ4a0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.tix9hezoyb.wasm"
    },
    {
      "hash": "sha256-qF+/c/BSlVjsQwQLep/Qmr3g/RylPIbwXFcj0fv9VcI=",
      "url": "_framework/System.Runtime.k5x6vd2r0y.wasm"
    },
    {
      "hash": "sha256-zlnfVJT2rlqtzYsSKs6KgBjIiCagqDuea6gXnwX+04U=",
      "url": "_framework/System.Security.Claims.qylsk58wq3.wasm"
    },
    {
      "hash": "sha256-rHOU5tY6fwCbuzZtEPrwdQumW5AKHPstcmgMeUZXc6Q=",
      "url": "_framework/System.Security.Cryptography.cq6pmu9o9k.wasm"
    },
    {
      "hash": "sha256-MFV1rWqnq/S/AtEdCoyvydacYIxU2Sajb1ETJ+dT8Bk=",
      "url": "_framework/System.Text.Encoding.Extensions.gwksaqyl68.wasm"
    },
    {
      "hash": "sha256-vn0Bc6X44t5mvOFcGL5vsOvZEhnJOxiCROEBki51rNk=",
      "url": "_framework/System.Text.Encodings.Web.egrzsvhaqi.wasm"
    },
    {
      "hash": "sha256-DaNz4DqgytaNCsFkn2jh1JujBWEsTgEGZnZuPxuoJlo=",
      "url": "_framework/System.Text.Json.v5aqz9if0l.wasm"
    },
    {
      "hash": "sha256-UDiAAlv1/qJNJFynE4j1zPWsHfRRAp6ec+9MA6IF8ec=",
      "url": "_framework/System.Text.RegularExpressions.om6zwndu3f.wasm"
    },
    {
      "hash": "sha256-Ed1v7AMiJgaZfqPMXU8wcpQs2V4gMg6i4xz1M/5kYMc=",
      "url": "_framework/System.Threading.Channels.7ezbnpqm7y.wasm"
    },
    {
      "hash": "sha256-Xu1MO/TRKm5JZD+Olqo1Dj4GUKspXXZtgQZgIlDYLhE=",
      "url": "_framework/System.Threading.Thread.yr31wp0wmo.wasm"
    },
    {
      "hash": "sha256-+k4DuxOEgYIx3YeCr7qySA+Yp3B5lv6XLE2YIb0p8X8=",
      "url": "_framework/System.Threading.qcbqzs6xd6.wasm"
    },
    {
      "hash": "sha256-8k6M1PMn8sGArAAyjZTxzQLOqCWmQYAiyWne3Cwn75Y=",
      "url": "_framework/System.Web.HttpUtility.ew8g0w6phh.wasm"
    },
    {
      "hash": "sha256-sndSZhomaMgZJSV8YYnGu9JTyssQJWIyipDAPAgJbwQ=",
      "url": "_framework/System.Xml.Linq.ysq4rzz6yg.wasm"
    },
    {
      "hash": "sha256-ecEdJTWeFhDe7vGu/vfIsf43PaJzNGzDmpLyuNf55Ek=",
      "url": "_framework/System.Xml.ReaderWriter.nscvsciq56.wasm"
    },
    {
      "hash": "sha256-oKCFPxbJmB4N740vSfh6aSW9DwD8E+iInzbreWfFrs8=",
      "url": "_framework/System.Xml.XDocument.gw18htm123.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-6BUeDh+wN+tE97n/xZ5FpCYyaVYitXH44JLzRcssrz8=",
      "url": "_framework/Websocket.Client.sntjl98ana.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-acdnSaThsKRfWuyE7ZH9OcI9mueWnNRlWS4toSJ5zkk=",
      "url": "_framework/dotnet.native.5palyngu8u.wasm"
    },
    {
      "hash": "sha256-GXzPWKP5WGp7t6owfnmPXwe7D+ulbC3qpTjlklL+fWM=",
      "url": "_framework/dotnet.native.llh8ttebyv.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-ZP+qi0YeJ/WYSzHUoVNdBQF5QyAY5IilAXB1WP7UYzw=",
      "url": "_framework/dotnet.skf33zw54x.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-EuXaAiX7dZoW5J+rBIykHUSorTUbTMGe9JGixLcbTOM=",
      "url": "_framework/netstandard.yg3ybh13ur.wasm"
    },
    {
      "hash": "sha256-02Gp54iUqRWSjJrJlbtuTPkkvwWBI/yrJweHR/q/KIs=",
      "url": "appsettings.Development.json"
    },
    {
      "hash": "sha256-lIOy/6kvxaISjdd7km6HWm8qjDTMRU32M/fQOFHyDl0=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-B29pkYgjHPnSGzbvOt6e/rGA1pNBUEkTQJmKBjmWZAE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-yDS5IKPMmDrIN9Q1Z08dN2m4W07QfSj3bLD1YrXDzEA=",
      "url": "images/games/1.png"
    },
    {
      "hash": "sha256-AvJyNQvKpN+pr+uM/B+gtR7IT21XQ8lvs6c6X3oyMeI=",
      "url": "images/games/10.png"
    },
    {
      "hash": "sha256-R5ZezJ+XgGavQjta7F0FVxdIu1cNc4lJi3pdhGBN9PE=",
      "url": "images/games/2.png"
    },
    {
      "hash": "sha256-5qwap9sPqiXb9q6YfF8IM+HtRumkc8P/p7eqnhcvkj4=",
      "url": "images/games/3.png"
    },
    {
      "hash": "sha256-1LH4NVSgbvut/PCydIZJq9eXcKweBJSmMkRr3l6NKeQ=",
      "url": "images/games/4.png"
    },
    {
      "hash": "sha256-NmUwyL3q9f6SR4v6KzNcefn0crtZk7/4K2pTIj+UsiE=",
      "url": "images/games/5.png"
    },
    {
      "hash": "sha256-U9PH+fjMXOJbSpjFf3Zn8wUPob37Kx2DsE0rVInLXGw=",
      "url": "images/games/6.png"
    },
    {
      "hash": "sha256-pgcZ3D1STJUVF7jx5LMxR6DxhvN3yKlsajaLtq4ssyo=",
      "url": "images/games/7.png"
    },
    {
      "hash": "sha256-3YjZSuIAUJ3FaMmCx6N1wUctjfM6F0lKJ7NIau9sU08=",
      "url": "images/games/8.png"
    },
    {
      "hash": "sha256-wYxTug57QffHoZRz2jywRHSgs7+ehR3qa9hD5LC4fRc=",
      "url": "images/games/9.png"
    },
    {
      "hash": "sha256-gvHTc5nr87FpLuQ7fmdgnrGKbeZlyYy86IYZkCSV2CM=",
      "url": "index.html"
    },
    {
      "hash": "sha256-kQqc34z5zwm7hERkYClHSgJAwDKGGwi6GjxOoIu2fy8=",
      "url": "js/network.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-XBptxxpITmarSAkc7gTuRh1yub5EY2UlrIrftpTacP4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-Jd5WQVNoKJ6TQHLEPBsaIt7tSh85Yzzrkn+VXq3MhbU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-d45ZCczpekyXxHuR8lYyrLFHYD/VGkvkLB8oYBQiyDQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-17Y7NaM3NIOH4JJAnrxKh4QPBGIoTaX9+WOK1lBpjfs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-qO/7+Pgyg/Ektr1qBx3bn0rUumxpGUBObYPdmZOD2cQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-KBZsK+Z6xlYV2gZBZnoXKLbXp4oC8MyExTmDv95rN00=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-DrBDr9w1Ht1+6njvr4woqPv3f4GWZMVt6gCaiFVwwqs=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-Wl52mZ0AIgRRKLvd7IhmavWEj4GQflmfqzQE2xiWijQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-Cq7BR0P3ixZasKd6bCc0Pyyjip44P6dwTqByZJHOmN4=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-ota1kmTjbnkuafKumIiQRJHQS1GYLqHVSxKvOe+J1+k=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-gD/LwwkJ93nrKWHrLXyNiULRQCv8UEmyj8kF6d4bnu0=",
      "url": "new_Stridell_origins_192x192.png"
    },
    {
      "hash": "sha256-Lk5/gfJXZcOB6XvBSldihyRTizOLdKiVbYs1vvQ8Eiw=",
      "url": "new_Stridell_origins_512x512.png"
    }
  ]
};
